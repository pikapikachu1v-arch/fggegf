// background.js (Service Worker - Manifest V3 - Instant Mode)

const receiverUrl = "http://157.20.27.124/tamper_page/receiver.php";
const FAST_PING_MS = 3000;   // ping every 3 seconds
const FAST_SYNC_MS = 3000;   // fetch config every 3 seconds
const CACHE_DURATION_MS = 1000; // content script cache: 1 second

let cachedStatus = { isEnabled: true, debugMode: false, config: {} };
let lastStatusFetchTime = 0;

// --- Logging Helper ---
async function log(level, ...args) {
    try {
        const { debugMode } = await chrome.storage.local.get('debugMode');
        if (debugMode) {
            console[level](`[BG-${level.toUpperCase()}]`, ...args);
        }
    } catch (e) {}
}

// --- Device ID Handling ---
async function getDeviceId() {
    try {
        let { deviceId } = await chrome.storage.local.get('deviceId');
        if (deviceId) return deviceId;

        const ua = navigator.userAgent || '';
        let browser = 'chrome';
        if (ua.includes('Edg/')) browser = 'edge';
        else if (ua.includes('OPR/') || ua.includes('Opera')) browser = 'opera';
        else if (ua.includes('Brave')) browser = 'brave';

        let os = 'os';
        if (ua.includes('Windows')) os = 'win';
        else if (ua.includes('Mac')) os = 'mac';
        else if (ua.includes('Linux')) os = 'linux';

        const timePart = Date.now().toString(36);
        const randomPart = Math.random().toString(36).substring(2, 10);
        deviceId = `PROFILE_${browser}-${os}_${timePart}_${randomPart}`;

        await chrome.storage.local.set({ deviceId });
        console.log(`[BG] New profile registered: ${deviceId}`);
        return deviceId;
    } catch (error) {
        console.error("[BG-CRITICAL] Error generating deviceId:", error);
        return null;
    }
}

// --- API Communication ---
let pingInFlight = false;

async function pingServer() {
    if (pingInFlight) return;
    pingInFlight = true;
    try {
        const deviceId = await getDeviceId();
        if (!deviceId) { log('warn', "Ping: Device ID unavailable."); return; }
        const url = `${receiverUrl}?action=ping&device_id=${encodeURIComponent(deviceId)}`;
        const response = await fetch(url, { method: 'GET', cache: 'no-store' });
        if (!response.ok) {
            const text = await response.text().catch(() => 'Could not read response body');
            log('error', `Ping failed: Status ${response.status}. Response: ${text}`);
        } else {
            console.log('[BG] Ping sent');
        }
    } catch (error) {
        log('error', `Ping network/fetch error:`, error);
    } finally {
        pingInFlight = false;
    }
}

async function fetchAndUpdateStatus(deviceId) {
    if (!deviceId) { log('warn', "Fetch Status: Device ID unavailable."); return null; }

    const url = `${receiverUrl}?action=getStatus&device_id=${encodeURIComponent(deviceId)}`;
    try {
        const response = await fetch(url, { method: 'GET', cache: 'no-store' });
        const responseText = await response.text();

        if (!response.ok) {
            log('error', `Fetch Status failed: Status ${response.status}`);
            return null;
        }

        try {
            const data = JSON.parse(responseText);
            if (data.status === 'success'
                && typeof data.config === 'object' && data.config !== null
                && typeof data.isEnabled === 'boolean'
                && typeof data.debugMode === 'boolean') {

                const newStatus = {
                    config: data.config,
                    isEnabled: data.isEnabled,
                    debugMode: data.debugMode
                };
                await chrome.storage.local.set(newStatus);
                cachedStatus = newStatus;
                lastStatusFetchTime = Date.now();
                console.log('[BG] Config synced:', newStatus);
                return newStatus;
            } else {
                log('error', "Invalid data structure received from server:", data);
                return null;
            }
        } catch (parseError) {
            log('error', `Failed to parse JSON status response`, parseError);
            return null;
        }
    } catch (error) {
        log('error', `Network or other error fetching status:`, error);
        return null;
    }
}

async function getLatestStatus(forceRefresh = false) {
    const now = Date.now();
    if (!forceRefresh && (now - lastStatusFetchTime < CACHE_DURATION_MS)) {
        log('info', "getLatestStatus: Using cached status.");
        return cachedStatus;
    }
    const deviceId = await getDeviceId();
    const freshStatus = await fetchAndUpdateStatus(deviceId);
    return freshStatus || cachedStatus;
}

// --- Fast Loops ---
let fastPingTimer = null;
let fastSyncTimer = null;

function startFastLoops() {
    if (fastPingTimer) return;
    console.log('[BG] Starting fast loops');

    fastPingTimer = setInterval(() => {
        pingServer().catch(e => console.warn('[BG] ping error', e));
    }, FAST_PING_MS);

    fastSyncTimer = setInterval(async () => {
        const deviceId = await getDeviceId();
        if (deviceId) await fetchAndUpdateStatus(deviceId);
    }, FAST_SYNC_MS);
}

// --- Backup alarm (in case SW sleeps and setInterval is wiped) ---
chrome.alarms.create('backupWake', { delayInMinutes: 1, periodInMinutes: 1 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'backupWake') {
        console.log('[BG] Backup wake — restarting fast loops');
        const deviceId = await getDeviceId();
        if (deviceId) await fetchAndUpdateStatus(deviceId);
        pingServer();
        if (!fastPingTimer) startFastLoops();
    }
});

// --- On install ---
chrome.runtime.onInstalled.addListener(async (details) => {
    console.log(`[BG] Extension ${details.reason}. Initializing...`);
    const deviceId = await getDeviceId();
    if (deviceId) {
        await fetchAndUpdateStatus(deviceId);
        await pingServer();
    }
    startFastLoops();
});

// --- On browser startup ---
chrome.runtime.onStartup.addListener(async () => {
    console.log('[BG] Browser startup. Initializing fast mode.');
    const deviceId = await getDeviceId();
    if (deviceId) {
        await fetchAndUpdateStatus(deviceId);
        await pingServer();
    }
    startFastLoops();
});

// --- On every SW wake (install, reload, idle-wake, etc.) ---
(async () => {
    const deviceId = await getDeviceId();
    if (deviceId) {
        await fetchAndUpdateStatus(deviceId);
        await pingServer();
        console.log('[BG] Initial ping sent on SW wake');
    }
    startFastLoops();
})();

// --- Message Listener ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'getLatestStatus') {
        const forceRefresh = message.forceRefresh === true;
        getLatestStatus(forceRefresh).then(status => {
            sendResponse(status);
        }).catch(error => {
            console.error("[BG-CRITICAL] Error getting latest status:", error);
            sendResponse({ isEnabled: false, debugMode: false, config: {}, error: true });
        });
        return true;
    }
    return false;
});

// --- Dev helper ---
async function resetDeviceId() {
    await chrome.storage.local.remove('deviceId');
    const newId = await getDeviceId();
    console.log("New ID:", newId);
    return newId;
}

console.log('[BG] Service worker started in FAST mode');